package com.faizanahmad.we_book;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
